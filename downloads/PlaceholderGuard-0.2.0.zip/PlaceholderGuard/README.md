# PlaceholderGuard 0.2.0

**A Unity Editor package for tracking temporary content, reviewing placeholder candidates, managing production replacements, understanding project readiness, and checking builds for explicitly tagged placeholders.**

PlaceholderGuard is designed to make temporary development content visible and manageable. It combines explicit `PlaceholderTag` components with advisory name/folder heuristics, a local JSON registry, a replacement workflow, scan reports, a dashboard, and a pre-build validator.

> **Release status:** 0.2.0 is an early source-code release. It declares Unity 2021.3 as its minimum version and includes a conditional code path for Unity 6.4+'s serialized object-reference API. The package still needs to be compiled and tested in the exact Unity version and project where it will be used. Do not treat this README or the ZIP integrity check as proof of an in-Editor test.

---

## Contents

1. [What PlaceholderGuard does](#1-what-placeholderguard-does)
2. [Feature summary](#2-feature-summary)
3. [Requirements and installation](#3-requirements-and-installation)
4. [First-time setup](#4-first-time-setup)
5. [End-to-end workflow](#5-end-to-end-workflow)
6. [How scanning and detection work](#6-how-scanning-and-detection-work)
7. [Replacement lifecycle and safety](#7-replacement-lifecycle-and-safety)
8. [Dashboard guide](#8-dashboard-guide)
9. [Build validation](#9-build-validation)
10. [Registry and data model](#10-registry-and-data-model)
11. [Complete package structure and file-by-file reference](#11-complete-package-structure-and-file-by-file-reference)
12. [Tests](#12-tests)
13. [Troubleshooting](#13-troubleshooting)
14. [Known limitations and out-of-scope features](#14-known-limitations-and-out-of-scope-features)
15. [Upgrade from 0.1.0](#15-upgrade-from-010)
16. [Development notes](#16-development-notes)
17. [License](#17-license)

---

## 1. What PlaceholderGuard does

Game projects often contain temporary models, prototype characters, greybox objects, test audio, draft textures, and other content that should eventually be replaced or consciously approved before release.

PlaceholderGuard provides a workflow for:

1. **Marking known placeholders.** Add a `PlaceholderTag` component to a GameObject and describe why it is temporary.
2. **Finding possible placeholders.** Scan scenes, prefabs, and selected asset categories for names or folder paths that look temporary. These matches are suggestions, not confirmed placeholders.
3. **Recording intent.** Store placeholder identity, location, type, reason, replacement path, status, and history in a project-local JSON registry.
4. **Managing replacements.** Link a candidate production asset, verify the link, and—where supported—apply a prefab to a scene-authored GameObject after confirmation.
5. **Reviewing project state.** See counts, categories, locations, scan issues, and a readiness estimate in the dashboard.
6. **Protecting builds.** Warn or block a build when explicitly tagged, non-exempt placeholders remain in enabled Build Settings scenes.

### Design principles

- Explicitly tagged placeholders are authoritative records.
- Heuristic matches remain advisory until a developer approves them.
- Linking a replacement is not the same as applying it.
- Applying a replacement is a separate, confirmed action.
- Scene modifications are not saved automatically.
- PlaceholderGuard does not silently delete or overwrite a production asset.
- Core scanning, registry, replacement management, analytics, reports, and build validation run locally in the Unity Editor. There is no cloud account or AI service in 0.2.0.

---

## 2. Feature summary

| Area | Included in 0.2.0 | Important boundary |
|---|---|---|
| Explicit tagging | `PlaceholderTag` component with ID, name, category, reason, and build exemption fields | Tags are attached to GameObjects, not arbitrary files |
| Project scan | Loaded and unopened scenes under `Assets`, prefab assets under `Assets`, and selected asset categories | Does not scan every Unity asset format or packages outside `Assets` |
| Suggestions | Name/folder heuristics for GameObjects and selected asset types | Suggestions can be false positives and require review |
| Missing references | Serialized object-reference checks on components in scanned scene/prefab hierarchies | Not a universal asset dependency validator |
| Replacement links | Select, link, verify, and unlink assets | Does not modify the placeholder by itself |
| Applying replacements | Confirmed prefab replacement of a scene-authored GameObject | Prefab instances, prefab contents, and asset-only records are not auto-applied |
| Undo | Uses Unity Undo for a scene replacement and listens for Undo/Redo to refresh state | Keep the operation in Unity's Undo history; still review and save the scene yourself |
| Analytics | Counts by status, type, and scene/asset path; readiness estimate | A project-management estimate, not a quality guarantee |
| Reports | Current scan export to JSON or CSV | Export reflects the latest scan held in the dashboard |
| Build protection | Pre-build warning or blocking for explicit non-exempt tags in enabled build scenes | Suggestions, asset-only records, and broken-reference issues do not block builds |
| AI generation | Not included | Dialogue generation, TTS, image/model/animation generation are future work |

---

## 3. Requirements and installation

### Requirements

- Unity **2021.3 or newer** as declared in `package.json`.
- A Unity project with a normal `Assets`, `Packages`, and `ProjectSettings` directory structure.
- No external Python service, API key, database, or network connection is required for the 0.2.0 core package.
- Unity Test Framework is needed only to run the included EditMode tests.

The code contains a `UNITY_6000_4_OR_NEWER` conditional for the newer Unity 6.4 serialized-reference API. Other Unity-version-specific behavior should still be checked in the target editor.

### Install by copying the package folder

1. Close Unity before changing the package folder.
2. Extract the ZIP file.
3. Open the extracted folder and locate the inner folder named `PlaceholderGuard`.
4. Open the Unity project root. In Unity Hub, use the project's three-dot menu and choose **Show in Explorer** (Windows), or open the project folder in your file manager.
5. Open the project's `Packages` folder.
6. Copy the entire inner `PlaceholderGuard` folder into `Packages`.
7. Confirm that `package.json` is directly inside `Packages/PlaceholderGuard/`.
8. Reopen Unity and wait for package import and script compilation.
9. Open **Tools → PlaceholderGuard → Open Dashboard**.

Expected layout:

```text
YourUnityProject/
├── Assets/
├── Packages/
│   ├── manifest.json
│   └── PlaceholderGuard/
│       ├── package.json
│       ├── Runtime/
│       ├── Editor/
│       ├── Tests/
│       └── Documentation/
├── ProjectSettings/
└── Library/
```

**Important:** Copy the extracted folder, not the ZIP file. Avoid an accidental nested path such as `Packages/PlaceholderGuard/PlaceholderGuard/package.json`. The correct path is `Packages/PlaceholderGuard/package.json`.

### Alternative: Add from disk through Package Manager

If you do not want to copy the package folder manually, use Unity Package Manager's **Add package from disk** command and select this package's `package.json` file. Do not also copy the same package into `Packages`; use one installation method only.

---

## 4. First-time setup

### 4.1 Open the dashboard

Use **Tools → PlaceholderGuard → Open Dashboard**. The window has four tabs:

- **Overview**
- **Placeholders**
- **Suggestions**
- **Reports**

The dashboard header contains two scan actions:

- **Scan Entire Project** — scans the wider project scope described below.
- **Scan Build Scenes** — scans only enabled scenes configured in Build Settings.

### 4.2 Tag a placeholder manually

1. Open a scene.
2. Select the GameObject that currently uses temporary content.
3. In the Inspector, choose **Add Component**.
4. Search for **Placeholder Tag** and add it.
5. Set the display name, reason, and asset category.
6. Decide whether it is genuinely allowed to remain in a build. If so, enable the exemption and provide a clear exemption reason.
7. Run **Scan Entire Project**.

`AssetId` is serialized and hidden in the Inspector. In the Editor, `OnValidate()` creates a GUID when the ID is empty and fills the display name from the GameObject name when the display name is empty.

### 4.3 Placeholder categories

`PlaceholderAssetType` contains:

| Value | Intended meaning |
|---|---|
| `Other` | General or uncategorized placeholder |
| `Audio` | Temporary audio content |
| `Texture` | Temporary texture content |
| `Model` | Temporary model or GameObject content |
| `Material` | Temporary material content |
| `Dialogue` | Temporary dialogue content |
| `Animation` | Temporary animation content |
| `Script` | Temporary script asset |

The category is also used by replacement compatibility checks. It is descriptive metadata; it does not automatically infer what is inside an arbitrary asset.

---

## 5. End-to-end workflow

This is the recommended everyday workflow for a Unity developer.

### Step 1 — Scan the project

1. Open the dashboard.
2. Click **Scan Entire Project**.
3. Allow Unity to finish scanning. A progress bar is shown while scene and prefab assets are processed.
4. Check the **Reports** tab for tagged placeholders, suggestions, missing references, missing scripts, duplicate IDs, and scan warnings.

The project scan:

- Checks currently loaded scenes first.
- Finds and scans other scene assets under `Assets`, opening them additively where needed and closing scenes it opened after scanning.
- Scans prefab assets under `Assets` by loading prefab contents and unloading them after inspection.
- Checks names and paths for selected asset types.
- Saves the resulting registry data.

The project scan is broader than the build scan and may take time on large projects.

### Step 2 — Review explicit placeholders

Open the **Placeholders** tab. Each registered item displays its name, category, target kind, location, and replacement status.

Use the search field to filter by:

- Display name
- Scene or asset path
- Asset category
- Placeholder ID

Select **Manage Replacement** for the record you want to work on.

### Step 3 — Choose and link a replacement

1. Select a placeholder record in the **Placeholders** tab.
2. In **Replacement manager**, assign an asset to the **Replacement asset** object field. You can drag an asset from the Project window into this field.
3. Click **Link Replacement**.
4. PlaceholderGuard checks that the selected asset is inside the project's `Assets/` folder, can be loaded, and is compatible with the placeholder category and target kind.
5. The path is stored in the registry and the status becomes `linked`.

**Linking does not change the scene.** It only records which production asset is intended to replace the placeholder.

### Step 4 — Verify the link

Click **Verify Link**. PlaceholderGuard rechecks that the selected asset still exists and passes the same category and target compatibility checks.

A successful verification changes the state to `verified`, unless the record is already `applied`. Verification confirms the link; it does not prove that the asset is visually or functionally correct in the game.

### Step 5 — Apply a supported scene replacement

Automatic application is limited to a tagged GameObject that is a scene-authored object in a `.unity` scene.

1. Link a compatible prefab and verify it.
2. Select the placeholder record.
3. Click **Apply Replacement to Scene**.
4. Read the confirmation dialog and choose **Apply Replacement** only when ready.
5. PlaceholderGuard instantiates the selected prefab in the recorded scene, copies the old object's local position, rotation, and scale, places it at the old sibling index, and reparents the old object's children under the new prefab.
6. The original tagged GameObject is removed through Unity's Undo system.
7. The scene is marked dirty, and the registry state becomes `applied`.
8. Review the changed scene and save it yourself when satisfied.

PlaceholderGuard does **not** save the scene automatically. Use **Edit → Undo** or **Ctrl+Z** to revert while the replacement operation remains in Unity's Undo history. The package listens for Undo/Redo events to refresh the stored replacement status when it can detect the original tagged object in loaded scenes.

#### What automatic application does not copy

The operation preserves the GameObject's local transform, sibling position, and children. It does not copy arbitrary components, component values, animation state, runtime state, references from other objects, or custom data from the old GameObject onto the replacement prefab. Review those dependencies manually before saving.

#### Unsupported automatic-apply targets

- A GameObject that belongs to a prefab instance.
- The contents of a prefab asset.
- An asset-only placeholder record.
- A non-GameObject placeholder.

These targets can still be tracked and, where compatible, linked and verified. They must be updated deliberately by editing the appropriate source asset or prefab.

### Step 6 — Review suggestions

Open the **Suggestions** tab after a project scan.

Each suggestion shows:

- Candidate name
- Target kind (`gameObject` or `asset`)
- Asset category
- Heuristic confidence score
- Context path and, for GameObjects, hierarchy path
- A plain-language reason for the match

For each candidate:

- **Locate** selects or pings the candidate in Unity where possible.
- **Approve as Placeholder** records it as a placeholder after a confirmation dialog.
- **Dismiss** marks the suggestion as dismissed so it does not appear in the pending list.

Approval behavior depends on the target:

- **Scene GameObject:** adds a `PlaceholderTag` through Unity Undo, marks the scene dirty, registers the tag, and updates suggestion status. Save the scene yourself.
- **Prefab GameObject:** loads the prefab contents, creates a pre-change backup under `Library/PlaceholderGuardBackups/`, adds the tag, and saves the prefab. If saving fails, the service attempts to restore the backup.
- **Standalone asset:** creates an asset-only registry record. It does not add a component to the file and is not currently a build blocker.

Review suggestions individually. A high confidence score is not proof that an asset is truly temporary.

### Step 7 — Review analytics and reports

Return to **Overview** for the project summary and readiness estimate. Use **Reports** to inspect the latest scan and export it as JSON or CSV.

The report is the latest scan kept in the open dashboard window. Run another scan to refresh it. Reopening the dashboard does not reconstruct a previous in-memory report automatically; the registry remains saved, but run a scan to populate a fresh report.

### Step 8 — Validate a build

Build validation runs automatically before a Unity build. By default, it blocks a build when non-exempt explicit `PlaceholderTag` components remain in enabled Build Settings scenes. The Overview tab contains a toggle to change between blocking and warning-only behavior.

A replacement link or verified link does not remove the original tag and therefore does not resolve the build finding. Apply the replacement and review the scene, remove the tag manually where appropriate, or use a documented exemption for a placeholder that is intentionally allowed to remain.

---

## 6. How scanning and detection work

### 6.1 Explicit tag detection

The scanner walks the transform hierarchy of each scanned scene and prefab, including inactive children. When it finds a `PlaceholderTag`, it registers or updates a `PlaceholderRecord` and creates a `tagged` finding.

Explicit tags are not inferred; they are deliberately added by a developer or through the suggestion-approval workflow.

### 6.2 Heuristic GameObject suggestions

An untagged GameObject may receive a suggestion if its name or the containing scene/prefab path matches a configured placeholder term or folder pattern.

Name terms include:

- `placeholder`
- `temporary`
- `temp_` and `_temp`
- `dummy`
- `proxy`
- `blockout`
- `greybox` and `graybox`
- `prototype`
- `wip`

A name that begins with `temp` (but not `template`) also qualifies when it has additional characters.

The current heuristic score is rule-based:

| Match | Score |
|---|---:|
| Strong terms such as `placeholder`, `dummy`, or `blockout` | 0.92 |
| Other configured name terms or the `temp` prefix rule | 0.78 |
| Configured temporary/prototype folder path | 0.72 |

These values are **heuristic scores, not machine-learning probabilities**. The scanner reports the first matching rule and its reason.

### 6.3 Heuristic asset suggestions

Under `Assets`, the scanner checks the names and paths of these asset types:

| Unity search type | Suggestion category |
|---|---|
| `Texture2D` | `Texture` |
| `Material` | `Material` |
| `AudioClip` | `Audio` |
| `AnimationClip` | `Animation` |
| `Prefab` | `Model` |

A suggestion is created only when the name or path matches the configured heuristic rules. The scan counts the assets checked separately from the number of suggestions.

### 6.4 Missing script detection

For every GameObject hierarchy inspected in a scanned scene or prefab, the scanner checks its components. If Unity returns a null component entry, the scanner adds a `missing-script` issue with error severity.

### 6.5 Missing serialized object-reference detection

For non-null components, the scanner inspects serialized properties. It looks for object-reference properties, skips the component's `m_Script` field, and reports a `missing-reference` issue when Unity reports a missing underlying reference identifier even though the resolved object reference is null.

This is limited to serialized component properties in scanned scene and prefab hierarchies. It does not inspect every possible Unity asset format, script-generated reference, addressable catalog, external file, or every relationship in the project.

### 6.6 Duplicate placeholder IDs

The report groups tagged findings by `assetId`. If an ID appears more than once, a `duplicate-id` warning is added. This can happen legitimately when the same tag is present in a prefab source and one or more instances. PlaceholderGuard does not automatically rewrite IDs because doing so could break identity links or references. Review the contexts before making changes.

### 6.7 Scan errors and warnings

If a scene or prefab cannot be opened or loaded for scanning, the scan records a `scan-error` warning and continues where possible. If an individual component cannot be inspected, an `inspection-warning` is recorded. Check the Console and the report's Issues section for details.

---

## 7. Replacement lifecycle and safety

### 7.1 Replacement states

A record's `replacementStatus` is intended to use these values:

| State | Meaning |
|---|---|
| `unlinked` | No replacement asset is currently linked |
| `linked` | A replacement asset path has been saved |
| `verified` | The linked asset currently exists and passes the compatibility checks |
| `applied` | PlaceholderGuard completed the supported scene replacement operation |

Typical progression:

```text
unlinked
   │ choose a compatible production asset
   ▼
linked
   │ click Verify Link
   ▼
verified
   │ confirm Apply Replacement (supported scene GameObjects only)
   ▼
applied
```

Unlinking returns a record to `unlinked`. Re-linking an existing record updates the stored path and sets it to `linked`.

**Important distinction:** `linked` and `verified` do not mean the placeholder has been removed from the scene. Build validation still sees the `PlaceholderTag` until the scene object is replaced or otherwise dealt with.

### 7.2 Compatibility checks

The replacement picker uses the placeholder's `assetType` and `targetKind`.

| Placeholder category | Accepted replacement asset type |
|---|---|
| `Other` | Any main asset type, subject to the additional GameObject rule below |
| `Audio` | `AudioClip` |
| `Texture` | `Texture` |
| `Material` | `Material` |
| `Model` | `GameObject` prefab asset |
| `Dialogue` | `TextAsset` or `ScriptableObject` |
| `Animation` | `AnimationClip` or `RuntimeAnimatorController` |
| `Script` | `MonoScript` |

Additional rules:

- The asset must be inside the project's `Assets/` folder.
- Unity must be able to load it using `AssetDatabase.LoadMainAssetAtPath`.
- A `gameObject` placeholder must link to a `GameObject` prefab asset, not a scene object.
- An asset-only placeholder can link compatible non-GameObject asset categories.

These are type checks, not semantic checks. For example, a prefab can pass the `Model` check without being the correct character or object for the scene.

### 7.3 Undo, history, and saving

- Link, unlink, verify, apply, and detected Undo/Redo events are recorded in registry history.
- The scene apply action uses Unity's Undo API for its scene-object changes.
- The scene is marked dirty but never saved automatically.
- A scene replacement may open the recorded scene additively if it is not already loaded. Review the open scene and save it yourself.
- Keep normal project backups and version control. Unity Undo is not a substitute for source control or a project backup.

---

## 8. Dashboard guide

### Header controls

**Scan Entire Project** runs the comprehensive project scan.

**Scan Build Scenes** scans only enabled scenes in Build Settings.

The message area below the header displays success, warning, or error feedback for the most recent dashboard action.

### Overview tab

Displays:

- Readiness estimate
- Registered placeholders
- Unlinked records
- Linked records
- Verified links
- Applied replacements
- Explicitly exempt records
- Pending suggestions
- Asset-only records
- Counts by category
- Counts by scene or asset path (up to the 12 most common contexts)
- Build-blocking preference toggle

The dashboard explains the readiness formula beside the score. Suggestions are not included in the score.

### Placeholders tab

Displays searchable placeholder records. Selecting **Manage Replacement** opens the replacement manager for that record.

The replacement manager contains:

- Selected placeholder name and ID
- Recorded target context and hierarchy path
- Replacement asset object field
- Link Replacement
- Verify Link
- Unlink (with confirmation)
- Apply Replacement to Scene (enabled only for supported scene GameObject records with a linked path)
- Locate
- Recent replacement history (up to 12 entries for that placeholder)

### Suggestions tab

Displays pending suggestions ordered by descending heuristic confidence. Each item includes the reason, location, category, and actions to approve, dismiss, or locate it.

### Reports tab

Displays the latest scan's:

- Scan scope and timestamp
- Tagged placeholder count
- Scene and prefab scan counts
- Candidate asset count checked
- Pending suggestion count
- Missing reference count
- Missing script count
- Duplicate ID count
- Findings and issues

Use **Export JSON** or **Export CSV** to save the current report through Unity's Save File dialog.

---

## 9. Build validation

`PlaceholderBuildValidator` implements `IPreprocessBuildWithReport`. Unity invokes it before a player build.

### Default behavior

Build blocking is enabled by default. The validator runs a scan of enabled Build Settings scenes and examines the explicit tagged findings.

A finding blocks the build when:

- `exemptFromBuildBlock` is false; **or**
- it is marked exempt but `exemptionReason` is empty or whitespace.

A placeholder is treated as exempt only when both the exemption checkbox is enabled and a non-empty reason is provided.

### Change blocking to warnings

Open **Tools → PlaceholderGuard → Open Dashboard → Overview** and disable:

**Block builds when tagged placeholders remain in enabled build scenes**

The preference is stored in Unity `EditorPrefs` under:

```text
PlaceholderGuard/BlockBuilds
```

When blocking is off, the build continues and PlaceholderGuard logs a warning. When blocking is on, it throws `BuildFailedException` and stops the build.

### What does not currently block a build

- Pending or approved heuristic suggestions by themselves
- Asset-only placeholder records
- Missing object-reference issues
- Missing script issues
- Duplicate ID warnings

These are visible in scan reports but do not currently participate in the build-blocking decision.

---

## 10. Registry and data model

### Registry location

The local registry is stored at:

```text
ProjectSettings/PlaceholderGuard/registry.json
```

The registry is plain JSON and is suitable for inspection and version control. If the team needs to share decisions and replacement links, include this file in source control and agree on how concurrent edits will be handled. Unity `EditorPrefs` settings are local to the editor/user and are not part of the registry.

### Top-level schema

`PlaceholderRegistryData` currently uses schema version `2` and has three lists:

```json
{
  "schemaVersion": 2,
  "placeholders": [],
  "suggestions": [],
  "history": []
}
```

### PlaceholderRecord fields

| Field | Purpose |
|---|---|
| `assetId` | Stable identity for a tagged GameObject or asset-only record |
| `displayName` | Friendly name shown in the dashboard |
| `assetType` | Category such as `Model`, `Audio`, or `Texture` |
| `targetKind` | `gameObject` for a tagged object; `asset` for a standalone asset record |
| `createdAtUtc` | UTC timestamp when the record was first created |
| `updatedAtUtc` | UTC timestamp of the latest registry update |
| `sceneOrPrefab` | Scene path, prefab path, or standalone asset path |
| `gameObjectPath` | Slash-separated hierarchy path for a GameObject record |
| `reason` | Why the item is considered temporary |
| `replacementAssetPath` | Unity project path to the intended replacement |
| `replacementStatus` | `unlinked`, `linked`, `verified`, or `applied` |
| `exemptFromBuildBlock` | Whether the developer has marked it as exempt |
| `exemptionReason` | Explanation required for a valid build exemption |

### PlaceholderSuggestion fields

| Field | Purpose |
|---|---|
| `suggestionId` | Stable suggestion identifier derived from the suggestion key |
| `suggestionKey` | Key used to update the same candidate on later scans |
| `targetKind` | `gameObject` or `asset` |
| `assetPath` | Candidate path when the target is a standalone asset |
| `contextPath` | Scene, prefab, or asset path that contains the candidate |
| `gameObjectPath` | Hierarchy path for a GameObject candidate |
| `displayName` | Candidate name |
| `assetType` | Suggested category |
| `confidence` | Heuristic score from the configured rules |
| `reason` | Explanation of the matched heuristic |
| `status` | `pending`, `approved`, or `dismissed` |
| `firstSeenUtc` / `lastSeenUtc` | Timestamps for first and most recent observation |

Existing suggestion decisions are preserved when the same candidate is found in later scans. The registry retains suggestion records; a candidate that no longer appears in a scan is not automatically removed from the registry.

### PlaceholderHistoryEntry fields

History entries record:

- UTC action time
- Placeholder ID
- Action name
- Previous replacement path
- New replacement path
- Scene/prefab/asset context
- Human-readable details

History is for traceability. It is not a general asset versioning system and does not itself restore an asset.

### Registry migration and recovery

When a v1 registry is loaded, the package upgrades it in memory to schema version 2 and fills newly introduced lists/default fields. On the next save it attempts to create a timestamped v1 backup beside the registry before writing schema version 2.

If JSON parsing fails, the package attempts to make a timestamped `.corrupt-...bak` copy and loads a new empty in-memory registry. This does not mean the old data was repaired. Check the Console and restore a known-good backup before continuing if the registry contains important data. Keep a manual backup before upgrading or editing registry files.

The registry save routine writes a temporary file and then replaces the current JSON file where supported.

### Other local data

| Location | Purpose | Source control guidance |
|---|---|---|
| `ProjectSettings/PlaceholderGuard/registry.json` | Placeholder records, suggestions, and history | Commit if the team wants shared state |
| `Library/PlaceholderGuardBackups/` | Backups created before approving a prefab suggestion | Normally do not commit; `Library` is generated/local data |
| Unity `EditorPrefs` key `PlaceholderGuard/BlockBuilds` | Local build blocking preference | Not shared through the registry |

---

## 11. Complete package structure and file-by-file reference

The package layout is:

```text
PlaceholderGuard/
├── package.json
├── README.md
├── LICENSE
├── Runtime/
│   ├── PlaceholderTag.cs
│   └── PlaceholderGuard.Runtime.asmdef
├── Editor/
│   ├── PlaceholderGuard.Editor.asmdef
│   ├── Analytics/
│   │   └── PlaceholderAnalytics.cs
│   ├── Dashboard/
│   │   └── PlaceholderGuardWindow.cs
│   ├── Models/
│   │   └── PlaceholderRecord.cs
│   ├── Registry/
│   │   └── AssetRegistry.cs
│   ├── Replacement/
│   │   └── ReplacementService.cs
│   ├── Reports/
│   │   └── PlaceholderReportExporter.cs
│   ├── Scanner/
│   │   └── PlaceholderScanner.cs
│   ├── Suggestions/
│   │   └── PlaceholderSuggestionService.cs
│   └── Validation/
│       └── PlaceholderBuildValidator.cs
├── Tests/
│   └── Editor/
│       ├── PlaceholderAnalyticsTests.cs
│       └── PlaceholderGuard.Tests.asmdef
└── Documentation/
    ├── CHANGELOG.md
    ├── QUICK_START.md
    ├── UPGRADE_0.2.0.md
    └── sample-registry.json
```

### Root files

#### `package.json`

Unity Package Manager manifest for the package.

It defines:

- Package ID: `com.placeholderguard.core`
- Version: `0.2.0`
- Display name: `PlaceholderGuard`
- Description
- Declared minimum Unity version: `2021.3`
- Author metadata

Unity reads this file to recognize the folder as a package. It must sit directly in the package root.

#### `README.md`

This end-to-end guide. It explains installation, the intended workflow, dashboard, file architecture, registry, limitations, tests, and upgrade process.

#### `LICENSE`

The MIT license text governing use, copying, modification, distribution, and warranty disclaimer. Review this file when redistributing the package.

### Runtime files

#### `Runtime/PlaceholderTag.cs`

Defines the runtime-safe `PlaceholderTag` MonoBehaviour and the `PlaceholderAssetType` enum.

**Responsibilities:**

- Stores the serialized placeholder ID, display name, reason, category, build-exemption flag, and exemption reason.
- Exposes read-only properties for the stored values.
- Provides `Configure(...)` for setting the tag values from editor code or other code with access to the component.
- Uses `[DisallowMultipleComponent]` so a GameObject cannot have multiple copies of this tag through normal component addition.
- Uses `OnValidate()` under `UNITY_EDITOR` to generate a GUID if the ID is blank and default the display name to the GameObject name.

The component is intentionally small so it can remain attached to a scene or prefab GameObject. It does not itself scan, link, replace, or block a build; Editor-side systems perform those tasks.

The enum values are `Other`, `Audio`, `Texture`, `Model`, `Material`, `Dialogue`, `Animation`, and `Script`.

#### `Runtime/PlaceholderGuard.Runtime.asmdef`

Assembly Definition for the runtime assembly named `PlaceholderGuard.Runtime`. It has no Editor-only platform restriction and no additional assembly references. It keeps the runtime tag component in a separate assembly from UnityEditor-dependent code.

### Editor files

#### `Editor/PlaceholderGuard.Editor.asmdef`

Assembly Definition for the Editor assembly named `PlaceholderGuard.Editor`.

It references `PlaceholderGuard.Runtime` and is restricted to the Editor platform. This prevents files that use `UnityEditor`, `AssetDatabase`, Editor windows, scene editor APIs, build callbacks, and Undo APIs from being compiled into player builds.

#### `Editor/Models/PlaceholderRecord.cs`

Declares the serializable data classes used by the registry, scanner, dashboard, analytics, and exporter:

- `PlaceholderRegistryData` — schema version plus placeholder, suggestion, and history lists.
- `PlaceholderRecord` — stored placeholder and replacement state.
- `PlaceholderSuggestion` — an advisory candidate and its review status.
- `PlaceholderHistoryEntry` — a timestamped audit entry for an action.
- `ScanReport` — metadata and collections from one scan.
- `ScanFinding` — a confirmed tagged placeholder finding.
- `ScanIssue` — a warning or error such as a missing reference or scan failure.

This file contains data models rather than Unity UI or scanning logic. Unity's `JsonUtility` serializes the registry/report model classes.

#### `Editor/Registry/AssetRegistry.cs`

Central persistence and record-management layer. It reads and writes `ProjectSettings/PlaceholderGuard/registry.json`.

Key members:

- `RegistryDirectory` / `RegistryPath` — define the registry location.
- `Data` — lazy-loaded access to the cached registry data.
- `Load()` — reads JSON, initializes lists/default values, upgrades older schema data in memory, and attempts a backup if parsing fails.
- `EnsureCollections()` — ensures lists exist and fills defaults for target kind and replacement status.
- `Save()` — writes schema version 2 through a temporary file; creates a v1 backup before the first migrated save when applicable.
- `Register(...)` — creates or updates a record from a `PlaceholderTag`, including context and hierarchy path; it tries to retain the scene context over a prefab-source context when the same tag ID appears in both.
- `RegisterAsset(...)` — creates or updates an asset-only record using the Unity asset GUID.
- `LinkReplacement(...)` — validates a non-empty `Assets/` path and loadable main asset, stores the path, marks the state `linked`, and records history.
- `UnlinkReplacement(...)` — removes the saved path, resets the state to `unlinked`, and records history.
- `SetReplacementStatus(...)` — changes status and records the previous status/details.
- `AddHistory(...)` — appends a history entry to the in-memory registry; a later save persists it.
- `UpsertSuggestion(...)` — inserts a new suggestion or refreshes an existing matching suggestion while preserving its approved/dismissed decision.
- `SetSuggestionStatus(...)` — marks a suggestion approved or dismissed and saves.
- `Find(...)` — returns a placeholder record by ID.

Other Editor systems should use this registry instead of writing the JSON file independently.

#### `Editor/Scanner/PlaceholderScanner.cs`

Implements the project and build-scene scans.

Key members:

- `ScanProject()` — reloads the registry, scans loaded scenes, scans all scene assets under `Assets`, scans prefab assets under `Assets`, checks selected candidate asset types, reports duplicate IDs, saves registry data, and calculates report totals.
- `ScanBuildScenes()` — scans only enabled scenes in Unity Build Settings, then reports tagged placeholders and scan issues for that scope.
- `ScanLoadedScenes(...)` — scans currently loaded scenes once per scene path.
- `ScanAllSceneAssets(...)` — finds scene assets under `Assets` and scans those not already visited.
- `ScanScenePath(...)` — opens a scene additively when it is not loaded, scans it, and closes it if the scanner opened it; captures scan exceptions as issues.
- `ScanScene(...)` — walks each root GameObject in a valid loaded scene.
- `ScanPrefabAssets(...)` — finds prefab assets, loads prefab contents, scans their hierarchy, and unloads contents in a `finally` block.
- `ScanHierarchy(...)` — visits all child transforms including inactive objects, inspects component references, registers explicit tags, and makes suggestions for untagged GameObjects.
- `InspectMissingReferences(...)` — checks components for missing scripts and serialized object references.
- `BuildGameObjectSuggestion(...)` — creates a stable suggestion key and candidate record for a matching untagged GameObject.
- `ScanCandidateAssets(...)` — checks Texture2D, Material, AudioClip, AnimationClip, and Prefab asset names/paths.
- `EvaluateHeuristics(...)` — applies the configured name and folder rules and assigns a heuristic score/reason.
- `AddDuplicateIdIssues(...)` — adds warnings when an ID appears in multiple tagged findings.
- `GetHierarchyPath(...)` — returns a slash-separated path from root to GameObject.
- `StableId(...)` — generates a deterministic ID from a string using MD5; this is used for suggestion identity, not as a security credential.

#### `Editor/Suggestions/PlaceholderSuggestionService.cs`

Implements the user-approved transition from a suggestion to a tracked placeholder.

Key members:

- `Approve(...)` — dispatches approval based on target kind and context path.
- `ApproveSceneSuggestion(...)` — opens the scene additively if needed, finds the GameObject by hierarchy path, refuses if it already has a tag, adds a tag through Unity Undo, configures/registers it, marks the scene dirty, and updates the suggestion status.
- `ApprovePrefabSuggestion(...)` — loads prefab contents, finds the target, writes a pre-change backup under `Library/PlaceholderGuardBackups/`, adds/configures the tag, saves the prefab, and attempts to restore the backup if saving fails.
- `Dismiss(...)` — stores the dismissed suggestion state.
- `FindByPath(...)` — locates a GameObject by its generated hierarchy path in a scene or prefab hierarchy.

This service does not auto-approve all suggestions. The dashboard asks for confirmation before calling it.

#### `Editor/Replacement/ReplacementService.cs`

Contains validation, verification, application, and Undo/Redo status support for replacement operations.

Key members:

- `ValidateReplacement(...)` — checks the target record, selected asset path, asset loadability, category compatibility, GameObject/prefab requirements, and target-kind rules.
- `VerifyLink(...)` — reruns validation and marks the link `verified` unless the record is already `applied`.
- `ApplyToScene(...)` — validates the record, checks support constraints, loads the replacement prefab, opens the target scene additively if needed, locates the original tag by path and ID, refuses ambiguous matches and prefab instances, instantiates the prefab, preserves local transform/sibling order/children, removes the old object through Unity Undo, marks the scene dirty, records history, and sets the state to `applied`.
- `FindTarget(...)` — locates the exact tagged GameObject by hierarchy path and asset ID; returns no target if the result is ambiguous.
- `ReplacementUndoWatcher` — subscribes to Unity's Undo/Redo event and tries to refresh `applied`/`linked` status when it detects restoration or reapplication of the tagged object in currently loaded scenes.

The service never calls `EditorSceneManager.SaveScene`. Saving remains the developer's responsibility.

#### `Editor/Analytics/PlaceholderAnalytics.cs`

Calculates dashboard counts from registry data.

- `PlaceholderAnalyticsSummary` holds total, unlinked, linked, verified, applied, exempt, pending-suggestion, asset-only, and readiness values.
- `BuildSummary(...)` calculates those values and the readiness score.
- `CountByType(...)` groups records by placeholder category.
- `CountByScene(...)` groups records by their context path.

Readiness formula:

```text
resolved = applied records
         + records explicitly exempted with a non-empty exemption reason

readiness = round(100 × resolved / all tracked records)
```

If no records exist, readiness is `100`. A `linked` or `verified` record is not counted as resolved. Pending suggestions are not included in the denominator.

#### `Editor/Reports/PlaceholderReportExporter.cs`

Exports the most recent `ScanReport` supplied by the dashboard.

- `ExportJson(...)` opens a Save File dialog and writes the report using Unity `JsonUtility` with readable indentation.
- `ExportCsv(...)` opens a Save File dialog and writes findings, issues, and suggestions as CSV rows.
- `Csv(...)` wraps cell values in quotes and escapes embedded quote characters.

The exporter does not run a scan itself. Run a scan first so the dashboard has a report to export.

#### `Editor/Dashboard/PlaceholderGuardWindow.cs`

Implements the custom Unity Editor dashboard and connects UI actions to the other services.

- Menu entry: **Tools → PlaceholderGuard → Open Dashboard**.
- `OnEnable()` loads the build-blocking preference and registry.
- `OnGUI()` draws the header and routes to the selected tab.
- `DrawHeader()` renders the scan buttons and status message.
- `DrawOverview()` renders readiness, status counts, category/context counts, and the build blocking toggle.
- `DrawPlaceholders()` renders searchable records and the replacement manager.
- `DrawHistory(...)` shows up to 12 recent history entries for a selected placeholder.
- `DrawSuggestions()` presents pending suggestions and approve/dismiss/locate actions.
- `DrawReports()` displays scan totals, findings, issues, and JSON/CSV export controls.
- `RunProjectScan()` and `RunBuildScan()` invoke the relevant scanner methods and refresh registry data.
- `SelectRecord(...)` selects a placeholder for replacement management.
- `LocateRecord(...)` selects or pings an asset, prefab, or scene GameObject where possible.
- `LocateSuggestion(...)` locates a suggested asset or GameObject where possible.
- `TrySelect(...)` locates a tagged GameObject from a report finding.
- `SetMessage(...)` updates dashboard feedback.
- `Contains(...)` performs case-insensitive filtering for the search field.

The dashboard is a Unity Editor window, not a separate web app. Its latest scan report is held by the window until another scan is run or the window/session is recreated.

#### `Editor/Validation/PlaceholderBuildValidator.cs`

Implements `IPreprocessBuildWithReport` and runs before a Unity player build.

`OnPreprocessBuild(...)`:

1. Reads `PlaceholderGuard/BlockBuilds` from `EditorPrefs` (default `true`).
2. Calls `PlaceholderScanner.ScanBuildScenes()`.
3. Filters findings so only explicit tags with a valid documented exemption are allowed through.
4. Logs success when there are no blocking findings.
5. Throws `BuildFailedException` when blocking is enabled and unresolved tagged placeholders remain.
6. Logs a warning and allows the build to continue when warning-only mode is selected.

It does not currently fail a build for heuristic suggestions, asset-only records, missing references, missing scripts, or duplicate IDs.

### Tests

#### `Tests/Editor/PlaceholderAnalyticsTests.cs`

Contains NUnit EditMode tests for the readiness calculation:

- `EmptyRegistryHasFullReadiness()` — verifies that an empty registry has readiness `100` and zero tracked records.
- `AppliedAndExemptRecordsCountAsResolved()` — verifies that applied and properly exempt records count as resolved, while a merely linked record does not.

These tests cover analytics calculations only. They are not a full integration test suite for scene scanning, asset operations, build callbacks, or replacement application.

#### `Tests/Editor/PlaceholderGuard.Tests.asmdef`

Defines the Editor test assembly and references `PlaceholderGuard.Runtime`, `PlaceholderGuard.Editor`, and Unity's optional `TestAssemblies` references. `autoReferenced` is false so the tests remain a separate test assembly.

### Documentation files

#### `Documentation/QUICK_START.md`

Short practical setup and usage instructions: install, tag a placeholder, link and apply a replacement, review suggestions, export reports, and understand build validation.

#### `Documentation/UPGRADE_0.2.0.md`

Upgrade instructions from 0.1.0 to 0.2.0, including backing up the registry, replacing the package folder, and how schema version 1 is migrated.

#### `Documentation/CHANGELOG.md`

Release-by-release summary of features introduced in 0.2.0 and the original 0.1.0 foundation.

#### `Documentation/sample-registry.json`

Example schema version 2 registry containing a sample GameObject placeholder, linked replacement path, status, and empty suggestion/history lists. It is illustrative data; do not overwrite your real registry with it.

---

## 12. Tests

The package includes two EditMode tests for the readiness-score calculation. It does **not** yet include automated tests for replacement application, scanning, prefab approval, missing-reference detection, report export, or build validation.

### Enable the test assembly

1. Ensure Unity Test Framework is installed through Package Manager if it is not already available.
2. Open `Packages/manifest.json`.
3. Add the package ID to the existing `testables` array without removing the project's other dependencies or settings. For example:

```json
{
  "dependencies": {
    "com.unity.test-framework": "<your-installed-version>"
  },
  "testables": [
    "com.placeholderguard.core"
  ]
}
```

This shows the `testables` entry only for illustration. Preserve your project's existing dependencies and their versions; do not replace your manifest with this example. If Unity Test Framework is already installed, keep its current version.

4. Save the manifest and let Unity resolve packages.
5. Open **Window → General → Test Runner**.
6. Select **EditMode** and run the PlaceholderGuard tests.

If Unity does not show the test assembly, check the Console, confirm the package ID in `testables` exactly matches `package.json`, and verify Unity Test Framework is installed.

### Testing recommendation before a real project build

Use a disposable copy of a small Unity project first. Create one explicitly tagged scene object, one test prefab, one name-based suggestion, and one documented exemption. Exercise each operation and inspect the scene, registry JSON, Undo/Redo behavior, and build callback before enabling the package on a production project.

---

## 13. Troubleshooting

### The Tools → PlaceholderGuard menu does not appear

- Wait for Unity to finish importing and compiling.
- Open **Window → General → Console** and inspect the first compile error (later errors may be consequences of the first one).
- Confirm `package.json` is directly inside `Packages/PlaceholderGuard/`.
- Confirm the old package folder was removed before copying the new version; duplicate package folders can create duplicate assembly names or menu confusion.
- Confirm `Editor/PlaceholderGuard.Editor.asmdef` is inside the Editor folder and its reference matches `PlaceholderGuard.Runtime`.

### Unity says the Packages folder is read-only

Do not paste into Unity's Project window. Open the actual project directory in Windows File Explorer (Unity Hub → project menu → **Show in Explorer**), then paste the extracted `PlaceholderGuard` folder into the file-system `Packages` directory.

### Replacement asset is rejected

- Confirm the selected asset is inside `Assets/`, not `Packages/` or an external directory.
- Confirm Unity has imported it and it can be loaded.
- Check the placeholder category against the compatibility table.
- A GameObject placeholder requires a prefab asset, not a scene object.

### Apply Replacement is disabled or fails

- Automatic application only supports tagged GameObjects recorded in `.unity` scenes.
- Prefab instances and prefab asset contents are deliberately not auto-applied.
- Run **Scan Entire Project** again if the recorded object path is stale.
- Ensure the object can be uniquely located by its stored hierarchy path and tag ID. If more than one match exists, PlaceholderGuard refuses to guess.
- Verify that the replacement prefab is still present and compatible.

### The original placeholder still appears in the build scan after linking

That is expected. Linking and verification only save a replacement path and confirm that it exists. They do not remove the `PlaceholderTag`. Apply the replacement where supported, remove the tag manually after review, or create a documented exemption if the placeholder is intentionally allowed.

### A suggestion looks incorrect

Name/folder heuristics are advisory and can produce false positives. Use **Dismiss**. Do not approve an item based only on its confidence score.

### A prefab was changed during approval

Placeholder approval creates a timestamped backup under `Library/PlaceholderGuardBackups/` before saving the new tag. If you need to restore the original prefab, close Unity or otherwise avoid further edits, locate the matching `.bak` file, and restore it carefully. Keep your version-control copy as the primary recovery option.

### The registry cannot be read

Check the Console for the registry parse error. PlaceholderGuard attempts to create a timestamped `.corrupt-...bak` copy, then loads an empty in-memory registry. Do not assume the registry was repaired. Restore a known-good `registry.json` backup before doing more scans or saves if the records matter.

### Readiness score seems unexpectedly high or low

The score is a simple record-level metric. `applied` records and records with both the exemption flag and a non-empty exemption reason count as resolved. `linked` and `verified` records do not. Asset-only records are included in the denominator. Pending suggestions are excluded. An empty registry receives 100 by definition.

### Report tab is empty

Run **Scan Entire Project** or **Scan Build Scenes**. The report is generated by a scan and is held in the current dashboard window; it is not automatically loaded from a previous report file.

---

## 14. Known limitations and out-of-scope features

PlaceholderGuard 0.2.0 is a local Unity Editor foundation, not the complete long-term product vision.

### Detection limitations

- Heuristics can be wrong and require manual review.
- Candidate asset scanning is limited to Texture2D, Material, AudioClip, AnimationClip, and Prefab assets under `Assets`.
- Missing-reference inspection is limited to serialized component properties in scanned scene and prefab hierarchies.
- Duplicate IDs are reported but are not automatically repaired.
- A record stores one primary context path and hierarchy path; repeated IDs across contexts need review.
- Pending suggestions are retained in the registry even if a later scan does not rediscover the candidate. The service checks that the target still exists when approval is attempted.

### Replacement limitations

- Automatic application is only for scene-authored GameObjects in scene files.
- The replacement needs to be a prefab/GameObject asset for GameObject placeholders.
- The operation preserves transform and child hierarchy, but does not remap all component data, external references, animations, or gameplay state.
- Prefab instances, prefab assets, and standalone asset placeholders require manual editing.
- Verification validates existence/type compatibility, not visual quality or gameplay correctness.
- Undo status refresh is best-effort and inspects currently loaded scenes.

### Build validation limitations

- Only explicit `PlaceholderTag` components in enabled Build Settings scenes block builds.
- Asset-only records, suggestions, missing references, missing scripts, and duplicate IDs are currently report-only.
- Build validation does not prove that every asset dependency is production-ready.

### Not included in 0.2.0

- AI dialogue generation or generative asset creation
- Text-to-speech synthesis
- Automatic image, texture, 3D model, or animation generation
- Cloud backend or hosted dashboard
- Universal asset-reference repair
- Unreal Engine adapter
- CI/CD service integration
- Complete automated integration tests

These are possible future development areas; they should not be presented as existing 0.2.0 functionality.

---

## 15. Upgrade from 0.1.0

1. Save the Unity project and close Unity.
2. Make a manual copy of `ProjectSettings/PlaceholderGuard/registry.json` outside the project.
3. Open the Unity project folder in File Explorer.
4. Open `Packages` and remove the old `PlaceholderGuard` folder.
5. Extract the 0.2.0 ZIP and copy its inner `PlaceholderGuard` folder into `Packages`.
6. Confirm there is only one package folder and `package.json` is directly inside it.
7. Reopen Unity and wait for compilation.
8. Open **Tools → PlaceholderGuard → Open Dashboard**.
9. Run **Scan Entire Project** and review the records and suggestions.
10. Keep the manual backup until you have confirmed the migrated data is correct.

The registry reader accepts the previous schema and fills the new suggestion/history collections. The next save upgrades the schema version to `2` and attempts to create a timestamped v1 backup beside `registry.json`.

Do not leave both the old and new package folders in `Packages`.

---

## 16. Development notes

### Namespaces

- Runtime tag and enum: `PlaceholderGuard`
- Editor systems and models: `PlaceholderGuard.Editor`
- Analytics tests: `PlaceholderGuard.Editor.Tests`

### Main dependency flow

```text
Unity scene / prefab GameObjects
              │
              ▼
   Runtime/PlaceholderTag.cs
              │ explicit metadata
              ▼
 Editor/Scanner/PlaceholderScanner.cs
       │                 │
       │                 └── heuristic candidates
       ▼                         ▼
Editor/Registry/AssetRegistry.cs ◄── PlaceholderSuggestionService.cs
       │
       ├── PlaceholderRecord.cs (shared data models)
       │
       ├── ReplacementService.cs
       │
       ├── PlaceholderAnalytics.cs
       │
       └── PlaceholderReportExporter.cs
                    │
                    ▼
       PlaceholderGuardWindow.cs
                    │
                    ▼
     Developer review / Unity Editor UI

Unity build pipeline
       │
       ▼
PlaceholderBuildValidator.cs
       │
       └── scans enabled Build Settings scenes
```

### Storage and trust boundaries

- The Unity Editor and `AssetDatabase` are the source of truth for whether an asset path resolves.
- The registry stores project-local metadata; it does not copy replacement assets.
- The scan report is a snapshot of one scan, not a continuously updated database view.
- Suggestions are untrusted candidates until a developer approves them.
- The readiness score is calculated from registry state and does not inspect the final built player.

### Suggested next engineering steps

Before adding AI services or expanding to other engines, strengthen the test suite around:

1. Scene scanning and scene open/close behavior.
2. Prefab scanning and prefab backup/restore behavior.
3. Replacement compatibility checks for every placeholder category.
4. Scene replacement transform/child preservation.
5. Undo and Redo status transitions.
6. Build blocking and valid/invalid exemption reasons.
7. Corrupt-registry recovery and schema migration.
8. Report JSON/CSV correctness on special characters and empty fields.

---

## 17. License

PlaceholderGuard is distributed under the MIT License. See [`LICENSE`](LICENSE) for the full license text.

---

**End of PlaceholderGuard 0.2.0 documentation.**
